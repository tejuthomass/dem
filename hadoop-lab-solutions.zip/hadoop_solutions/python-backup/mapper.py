import sys

for line in sys.stdin:
    data = line.strip().split(",")
    try:
        dept = data[2].strip()
        salary = int(data[3])
        print(dept + "\t" + str(salary))
    except:
        pass
