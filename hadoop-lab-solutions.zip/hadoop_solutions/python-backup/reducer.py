import sys

total = {}
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    key, value = line.split("\t")
    total[key] = total.get(key, 0) + int(value)

for key in sorted(total):
    print(key + "\t" + str(total[key]))
